from django.shortcuts import render

# Create your views here.
task = ["foo" , "bar" , "baz"]
def task (request):
    return render(request, 'task/index.html' , {
        "task" : task,
    })
